#!/usr/bin/env sh
hexo g
hexo d