---
title: Temporal Sychonization
date: 2020-08-12 16:42:00
tags:
---
