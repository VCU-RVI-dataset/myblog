---
title: about
date: 2020-08-12 16:11:56 
type: about
---

This paper presents VCU-RVI, a new visual in- ertial odometry (VIO) benchmark with a set of diverse data sequences in different indoor scenarios. The benchmark was captured using an Structure Core (SC) sensor, consisting of an RGB-D camera and an IMU. It provides aligned color and depth images with 640×480 resolution at 30 Hz. The camera’s data is synchronized with the IMU’s data at 100 Hz. Thirty-nine data sequences covering a total of ∼3.7 kilometers trajectory were recorded in various indoor environments by two experi- mental setups: hand-holding the SC sensor or installing it on a wheeled robot. For the data sequences from the handheld SC, some were recorded in our laboratory under three challenging conditions: fast sensor motion, radical illumination changing, and dynamic objects, and the rest were collected in various indoor spaces outside the laboratory in the East Engineering Building, including corridors, halls, and stairways, during long- distance navigation scenarios. For the data sequences captured using the wheeled robot, half of them were recorded with sufficient IMU excitation in the beginning of the sequence, to meet the need of testing the VIO methods with the requirement of sufficient motion conditions for initialization. We placed three bumpers on the floor of the lab to create an uneven terrain to make the robot motion 6-DOF. The sequences also include data collected from navigational courses with a long trajectory. For trajectory evaluation, a motion capture system is used to generate accurate pose data (at a rate of 120 Hz), which will be used as the ground truth. We conducted experiments to evaluate the state-of-the-art VIO algorithms using our benchmark. These algorithms together with the evaluation tools and the VCU-RVI dataset are made publicly available.


## Update!
All the files have been relinked due to the recent domain merge by the university.
https://global.vcu.edu/newsroom/2020/email/

Please use the link below:
https://drive.google.com/drive/folders/1yO10ty1IbC9aInYz7wdauiFoKlnjZCsc?usp=sharing
